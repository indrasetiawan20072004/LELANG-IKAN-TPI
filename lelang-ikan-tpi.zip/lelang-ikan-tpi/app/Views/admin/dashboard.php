<?= $this->include('layouts/header') ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="background: linear-gradient(135deg, #0c0c2d 0%, #1a1a4b 100%); min-height: 100vh; position: relative; overflow: hidden;">
    
    <!-- Space Ocean Background -->
    <div class="space-ocean">
        <div class="star star-1"></div>
        <div class="star star-2"></div>
        <div class="star star-3"></div>
        <div class="star star-4"></div>
        <div class="planet"></div>
        <div class="satellite">🛰️</div>
    </div>

    <!-- Holographic Header -->
    <div class="position-relative z-2">
        <div class="hologram-header rounded-3 mb-4 text-center py-5">
            <h1 class="display-4 fw-bold hologram-text">
                <i class="bi bi-stars me-3"></i>Mission Control
            </h1>
            <p class="lead fw-normal">Welcome, <strong class="cyber-glow"><?= session()->get('username') ?></strong></p>
            <div class="cyber-badge">
                <span class="blink">⚡</span> ADMIN ACCESS ACTIVATED
            </div>
        </div>

        <!-- Cyberpunk Statistics Grid -->
        <div class="row g-4 mb-4">
            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch data-text="PENDING">
                    <div class="card-body text-center">
                        <div class="cyber-icon">🚨</div>
                        <h3 class="cyber-number">12</h3>
                        <small>PENDING</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 60%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch data-text="APPROVED">
                    <div class="card-body text-center">
                        <div class="cyber-icon">✅</div>
                        <h3 class="cyber-number">89%</h3>
                        <small>APPROVED</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 89%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch data-text="REVENUE">
                    <div class="card-body text-center">
                        <div class="cyber-icon">💰</div>
                        <h3 class="cyber-number">48.7</h3>
                        <small>MILLION</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 75%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch data-text="OPERATORS">
                    <div class="card-body text-center">
                        <div class="cyber-icon">👥</div>
                        <h3 class="cyber-number">02</h3>
                        <small>OPERATORS</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 100%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch data-text="GROWTH">
                    <div class="card-body text-center">
                        <div class="cyber-icon">📈</div>
                        <h3 class="cyber-number">+15%</h3>
                        <small>GROWTH</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 15%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch data-text="SECURE">
                    <div class="card-body text-center">
                        <div class="cyber-icon">🔒</div>
                        <h3 class="cyber-number">100%</h3>
                        <small>SECURE</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 100%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Holographic Control Panel (Modified) -->
        <div class="row g-4 mb-4">
            <div class="col-lg-6">
                <div class="hologram-panel">
                    <div class="panel-header">
                        <h4><i class="bi bi-cpu-fill me-2"></i>SYSTEM CONTROLS</h4>
                    </div>
                    <div class="panel-body">
                        <div class="control-grid">
                            <a href="<?= site_url('/admin/verifikasi-karcis-bakul') ?>" class="control-item verify-control" title="Verifikasi Karcis Bakul">
                                <div class="control-icon">🔍</div>
                                <span>VERIFICATION</span>
                                <div class="status-dot online"></div>
                            </a>

                            <!-- MENU LAPORAN di admin -->
                            <a href="<?= site_url('/admin/laporan') ?>" class="control-item analytics-control" title="Laporan / Analytics">
                                <div class="control-icon">📊</div>
                                <span>ANALYTICS</span>
                                <div class="status-dot online"></div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="hologram-panel">
                    <div class="panel-header">
                        <h4><i class="bi bi-tools me-2"></i>MANAGEMENT TOOLS</h4>
                    </div>
                    <div class="panel-body">
                        <div class="control-grid">
                            <a href="<?= site_url('/laporan') ?>" class="control-item report-control">
                                <div class="control-icon">📋</div>
                                <span>REPORTS</span>
                                <div class="status-dot online"></div>
                            </a>

                            <a href="<?= site_url('/laporan/exportExcel') ?>" class="control-item print-control">
                                <div class="control-icon">🖨️</div>
                                <span>EXPORT</span>
                                <div class="status-dot online"></div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Live System Monitor -->
        <div class="hologram-panel large">
            <div class="panel-header">
                <h4><i class="bi bi-radar me-2"></i>LIVE SYSTEM MONITOR</h4>
            </div>
            <div class="panel-body">
                <div class="system-grid">
                    <div class="system-item">
                        <div class="system-icon">💾</div>
                        <div class="system-info">
                            <span>DATA WAREHOUSE</span>
                            <div class="system-status online">ONLINE</div>
                        </div>
                    </div>
                    <div class="system-item">
                        <div class="system-icon">🖥️</div>
                        <div class="system-info">
                            <span>CONTROL TOWER</span>
                            <div class="system-status online">OPERATIONAL</div>
                        </div>
                    </div>
                    <div class="system-item">
                        <div class="system-icon">🔐</div>
                        <div class="system-info">
                            <span>SECURITY GRID</span>
                            <div class="system-status online">ACTIVE</div>
                        </div>
                    </div>
                    <div class="system-item">
                        <div class="system-icon">☁️</div>
                        <div class="system-info">
                            <span>BACKUP SYSTEM</span>
                            <div class="system-status online">SYNCED</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</main>

<!-- Styling -->
<style>
/* Space Ocean Background */
.space-ocean {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
    pointer-events: none;
}

.star {
    position: absolute;
    background: white;
    border-radius: 50%;
    animation: twinkle 3s infinite;
    opacity: 0.6;
}

.star-1 { width: 2px; height: 2px; top: 20%; left: 10%; animation-delay: 0s; }
.star-2 { width: 3px; height: 3px; top: 40%; left: 80%; animation-delay: 1s; }
.star-3 { width: 1px; height: 1px; top: 60%; left: 30%; animation-delay: 2s; }
.star-4 { width: 2px; height: 2px; top: 80%; left: 60%; animation-delay: 1.5s; }

@keyframes twinkle {
    0%, 100% { opacity: 0.2; transform: scale(1); }
    50% { opacity: 1; transform: scale(1.2); }
}

.planet {
    position: absolute;
    top: 6%;
    right: 6%;
    width: 90px;
    height: 90px;
    background: radial-gradient(circle, #4a4a8a, #2a2a5a);
    border-radius: 50%;
    animation: rotate 20s infinite linear;
    opacity: 0.9;
}

.satellite {
    position: absolute;
    top: 26%;
    right: 18%;
    font-size: 1.6rem;
    animation: orbit 15s infinite linear;
    opacity: 0.9;
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

@keyframes orbit {
    0% { transform: rotate(0deg) translateX(140px) rotate(0deg); }
    100% { transform: rotate(360deg) translateX(140px) rotate(-360deg); }
}

/* Holographic Effects */
.hologram-header {
    background: rgba(255,255,255,0.03);
    backdrop-filter: blur(14px);
    border: 1px solid rgba(255,255,255,0.06);
    position: relative;
    overflow: hidden;
    z-index: 2;
}

.hologram-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: -120%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(0,255,255,0.08), transparent);
    animation: hologramScan 4s infinite;
}

@keyframes hologramScan {
    0% { left: -120%; }
    100% { left: 120%; }
}

.hologram-text {
    background: linear-gradient(45deg, #00ffff, #ff00ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: 0 0 24px rgba(0,255,255,0.35);
}

.cyber-badge {
    display: inline-block;
    margin-top: 8px;
    padding: 6px 12px;
    border-radius: 999px;
    background: rgba(0,0,0,0.25);
    border: 1px solid rgba(255,255,255,0.06);
    color: #bff;
    font-weight: 600;
    z-index: 3;
}

/* Cyberpunk Cards */
.cyber-card {
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(0,255,255,0.12);
    border-radius: 10px;
    padding: 14px;
    position: relative;
    overflow: hidden;
    transition: all 0.25s ease;
    z-index: 2;
}

.cyber-card:hover {
    border-color: rgba(0,255,255,0.4);
    box-shadow: 0 0 18px rgba(0,255,255,0.12);
    transform: translateY(-6px);
}

.cyber-number {
    font-size: 1.6rem;
    background: linear-gradient(45deg, #00ffff, #ff00ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin: 8px 0;
}

.cyber-bar {
    background: rgba(255,255,255,0.06);
    height: 6px;
    border-radius: 999px;
    margin-top: 10px;
    overflow: hidden;
}

.cyber-progress {
    height: 100%;
    background: linear-gradient(90deg, #00ffff, #ff00ff);
    animation: progressLoad 1.6s ease-in-out;
}

/* Glitch effect simplified for labels */
[data-glitch]::after,
[data-glitch]::before { display: none; }

/* Hologram Panels */
.hologram-panel {
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(0,255,255,0.12);
    border-radius: 12px;
    backdrop-filter: blur(8px);
    padding: 0;
    z-index: 2;
}

/* Panel header / body */
.panel-header {
    padding: 14px 18px;
    border-bottom: 1px solid rgba(255,255,255,0.03);
    display:flex;
    align-items:center;
    gap:10px;
    background: linear-gradient(180deg, rgba(255,255,255,0.01), rgba(255,255,255,0.02));
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
}

.panel-header h4 {
    margin: 0;
    font-size: 1rem;
    color: #cfeffd;
    display:flex;
    align-items:center;
    gap:8px;
}

.panel-body {
    padding: 18px;
}

/* Control grid and items */
.control-grid {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
}

.control-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-width: 120px;
    max-width: 100%;
    padding: 14px;
    border-radius: 10px;
    text-decoration: none;
    color: #e6f9ff;
    background: rgba(0,0,0,0.12);
    border: 1px solid rgba(255,255,255,0.02);
    transition: transform 0.18s ease, box-shadow 0.18s ease;
    position: relative;
}

.control-item:hover {
    transform: translateY(-6px);
    box-shadow: 0 6px 18px rgba(0,255,255,0.06);
    border-color: rgba(0,255,255,0.18);
}

.control-icon {
    font-size: 1.6rem;
    margin-bottom: 8px;
    filter: drop-shadow(0 0 6px rgba(0,255,255,0.12));
}

.control-item span {
    font-weight: 700;
    letter-spacing: 0.6px;
    font-size: 0.85rem;
}

/* Status dot */
.status-dot {
    position: absolute;
    top: 10px;
    right: 10px;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: 1px solid rgba(255,255,255,0.08);
    box-shadow: 0 0 6px rgba(0,0,0,0.4) inset;
}

.status-dot.online {
    background: radial-gradient(circle, #7ef0b8, #18b06f);
    box-shadow: 0 0 8px rgba(24,176,111,0.35);
}

.status-dot.offline {
    background: radial-gradient(circle, #ff9b9b, #ff5757);
    box-shadow: 0 0 8px rgba(255,87,87,0.25);
}

/* Live monitor */
.hologram-panel.large { margin-top: 6px; }

.system-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(200px,1fr));
    gap: 12px;
}

.system-item {
    display:flex;
    align-items:center;
    gap:12px;
    padding:8px 12px;
    background: rgba(255,255,255,0.02);
    border-radius: 8px;
    border: 1px solid rgba(255,255,255,0.02);
}

.system-icon { font-size: 1.6rem; }
.system-info span { display:block; font-weight:700; color:#dff7ff; }
.system-status { font-size: 0.8rem; margin-top:4px; padding:4px 8px; border-radius:999px; display:inline-block; background: rgba(0,0,0,0.25); color:#bff; }

/* Utility */
.cyber-glow { text-shadow: 0 0 10px rgba(0,255,255,0.25); }
.lead strong { color: #cfeffd; }

/* Responsive tweaks */
@media (max-width: 768px) {
    .control-grid { gap: 10px; }
    .control-item { min-width: 48%; }
    .cyber-card { padding: 12px; }
}
</style>
