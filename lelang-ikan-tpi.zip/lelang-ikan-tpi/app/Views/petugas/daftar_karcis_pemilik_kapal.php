<?= $this->include('layouts/header') ?>

<h2>Daftar Karcis Pemilik Kapal</h2>

<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nomor Karcis</th>
                        <th>Nama Nelayan/Kapal</th>
                        <th>Berat Ikan</th>
                        <th>Total Penjualan</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php foreach ($karcis as $k): ?>
                        <?php
                        // pastikan kita bisa akses elemen baik array maupun object
                        $row = is_array($k) ? $k : (array)$k;

                        // ambil total jika ada, kalau tidak coba hitung dari berat dan harga_per_kg
                        $total = null;
                        if (array_key_exists('total', $row) && $row['total'] !== null && $row['total'] !== '') {
                            $total = $row['total'];
                        } elseif (isset($row['berat']) && isset($row['harga_per_kg']) && $row['berat'] !== '' && $row['harga_per_kg'] !== '') {
                            // pastikan numeric sebelum dikalikan
                            $berat = (float) $row['berat'];
                            $harga = (float) $row['harga_per_kg'];
                            $total = $berat * $harga;
                        }

                        // format tanggal aman
                        $tanggal = '-';
                        if (!empty($row['created_at']) && strtotime($row['created_at']) !== false) {
                            $tanggal = date('d/m/Y', strtotime($row['created_at']));
                        }
                        ?>
                     <tr>
                        <td><?= $no++ ?></td>
                        <td><strong><?= $k['no_karcis'] ?></strong></td>
                        <td><?= $k['nama_pemilik'] ?></td>
                        <td><?= $k['nama_kapal'] ?></td>
                        <td><?= number_format($k['berat'], 2) ?> kg</td>
                        <td><strong>Rp <?= number_format($k['harga'], 0, ',', '.') ?></strong></td>
                        <td>
                            <?php if ($k['status_verifikasi'] == 'pending'): ?>
                                <span class="badge bg-warning">Menunggu Verifikasi</span>
                            <?php elseif ($k['status_verifikasi'] == 'approved'): ?>
                                <span class="badge bg-success">Terverifikasi</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Ditolak</span>
                            <?php endif; ?>
                        </td>
                        <td><?= $k['created_at'] ?></td>
                    </tr>
                    <?php endforeach; ?>

                    <?php if (empty($karcis)): ?>
                    <tr>
                        <td colspan="7" class="text-center">Belum ada data karcis</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<a href="<?= site_url('/petugas') ?>" class="btn btn-secondary mt-3">Kembali</a>

<?= $this->include('layouts/footer') ?>
