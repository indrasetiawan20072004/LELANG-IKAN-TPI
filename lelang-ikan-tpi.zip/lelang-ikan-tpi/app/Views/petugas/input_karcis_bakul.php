<?= $this->include('layouts/header') ?>

<div class="container-fluid">
    <div class="row">
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('/petugas') ?>">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?= site_url('/petugas/input-karcis-bakul') ?>">
                            <i class="bi bi-plus-circle"></i> Input Karcis Bakul
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= site_url('/petugas/input-karcis-pemilik-kapal') ?>">
                            <i class="bi bi-plus-circle"></i> Input Karcis Pemilik Kapal
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Input Karcis Bakul</h1>
            </div>

            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
            <?php endif; ?>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <form method="post" action="<?= base_url('working-input/bakul') ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Data Bakul</h5>
                                <div class="mb-3">
                                    <label for="nomor_karcis" class="form-label">Nomor Karcis *</label>
                                    <input type="text" class="form-control" id="nomor_karcis" name="nomor_karcis" required>
                                </div>
                                <div class="mb-3">
                                    <label for="nama_bakul" class="form-label">Nama Bakul *</label>
                                    <input type="text" class="form-control" id="nama_bakul" name="nama_bakul" required>
                                </div>
                                <div class="mb-3">
                                    <label for="alamat" class="form-label">Alamat *</label>
                                    <textarea class="form-control" id="alamat" name="alamat" rows="3" required></textarea>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <h5>Data Transaksi</h5>
                                <div class="mb-3">
                                    <label for="berat_ikan" class="form-label">Berat Ikan (kg) *</label>
                                    <input type="number" step="0.01" class="form-control" id="berat_ikan" name="berat_ikan" required>
                                </div>
                                <div class="mb-3">
                                    <label for="jumlah_karcis" class="form-label">Jumlah Karcis *</label>
                                    <input type="number" class="form-control" id="jumlah_karcis" name="jumlah_karcis" required>
                                </div>
                                <div class="mb-3">
                                    <label for="jumlah_pembelian" class="form-label">Jumlah Pembelian (Rp) *</label>
                                    <input type="number" step="0.01" class="form-control" id="jumlah_pembelian" name="jumlah_pembelian" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="jasa_lelang" class="form-label">Jasa Lelang (Rp) *</label>
                                    <input type="number" step="0.01" class="form-control" id="jasa_lelang" name="jasa_lelang" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="lain_lain" class="form-label">Lain-lain (Rp)</label>
                                    <input type="number" step="0.01" class="form-control" id="lain_lain" name="lain_lain" value="0">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="total" class="form-label">Total (Rp) *</label>
                                    <input type="number" step="0.01" class="form-control" id="total" name="total" required readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="jumlah_bayar" class="form-label">Jumlah Bayar (Rp) *</label>
                                    <input type="number" step="0.01" class="form-control" id="jumlah_bayar" name="jumlah_bayar" required>
                                </div>
                            </div>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" class="btn btn-primary">Simpan Karcis</button>
                            <a href="<?= site_url('/petugas') ?>" class="btn btn-secondary">Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
// Auto calculate total
document.addEventListener('DOMContentLoaded', function() {
    function calculateTotal() {
        const pembelian = parseFloat(document.getElementById('jumlah_pembelian').value) || 0;
        const jasaLelang = parseFloat(document.getElementById('jasa_lelang').value) || 0;
        const lainLain = parseFloat(document.getElementById('lain_lain').value) || 0;
        
        const total = pembelian + jasaLelang + lainLain;
        document.getElementById('total').value = total.toFixed(2);
    }
    
    // Attach event listeners
    ['jumlah_pembelian', 'jasa_lelang', 'lain_lain'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('input', calculateTotal);
    });

    // Trigger once on load
    calculateTotal();
});
</script>

<?= $this->include('layouts/footer') ?>
