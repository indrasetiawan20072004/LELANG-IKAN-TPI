<?php
// dashboard_petugas_tpi.php
// Inisialisasi data yang sebelumnya Anda simpan di controller
$title = 'Dashboard Petugas TPI';
$nama_lengkap = session()->get('username'); // gunakan username sesuai permintaan
?>

<?= $this->include('layouts/header') ?>

<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <p class="small text-muted mb-0">Selamat datang, <strong class="cyber-glow"><?= esc($nama_lengkap) ?></strong></p>
        </div>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="bi bi-download me-2"></i>Generate Report
        </a>
    </div>

    <!-- Content Row -->
    <div class="row">
        <!-- Total Karcis Bakul -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Total Karcis Bakul (Bulanan)
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">15</div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-cart-check fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Karcis Kapal -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Total Karcis Kapal (Bulanan)
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">8</div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-boat fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Transaksi -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Total Transaksi
                            </div>
                            <div class="row no-gutters align-items-center">
                                <div class="col-auto">
                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">Rp 25.4 JT</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-currency-dollar fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Menunggu Verifikasi -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Menunggu Verifikasi
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">3</div>
                        </div>
                        <div class="col-auto">
                            <i class="bi bi-clock fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Grafik & Pie -->
    <div class="row">
        <!-- Area Chart -->
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Grafik Transaksi Bulanan</h6>
                    <div class="dropdown no-arrow">
                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" 
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-three-dots-vertical text-gray-400"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow animated--fade-in" 
                            aria-labelledby="dropdownMenuLink">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                        </ul>
                    </div>
                </div>
                <div class="card-body">
                    <div class="chart-area" style="height: 320px;">
                        <div class="d-flex align-items-center justify-content-center h-100 text-muted">
                            <div class="text-center">
                                <i class="bi bi-bar-chart display-4 mb-3"></i>
                                <p>Grafik transaksi akan ditampilkan di sini</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pie Chart -->
        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Distribusi Karcis</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-4 pb-2" style="height: 280px;">
                        <div class="d-flex align-items-center justify-content-center h-100 text-muted">
                            <div class="text-center">
                                <i class="bi bi-pie-chart display-4 mb-3"></i>
                                <p>Diagram pie akan ditampilkan di sini</p>
                            </div>
                        </div>
                    </div>
                    <div class="mt-4 text-center small">
                        <span class="me-2">
                            <i class="bi bi-circle-fill text-primary"></i> Karcis Bakul
                        </span>
                        <span class="me-2">
                            <i class="bi bi-circle-fill text-success"></i> Karcis Kapal
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Progress + Quick Actions (dengan Laporan & Statistik ditambahkan) -->
    <div class="row">
        <!-- Progress Column -->
        <div class="col-lg-6 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Progress Bulanan</h6>
                </div>
                <div class="card-body">
                    <h4 class="small font-weight-bold">Karcis Bakul <span class="float-right">75%</span></h4>
                    <div class="progress mb-4">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 75%"></div>
                    </div>
                    <h4 class="small font-weight-bold">Karcis Kapal <span class="float-right">40%</span></h4>
                    <div class="progress mb-4">
                        <div class="progress-bar bg-success" role="progressbar" style="width: 40%"></div>
                    </div>
                    <h4 class="small font-weight-bold">Verifikasi <span class="float-right">60%</span></h4>
                    <div class="progress mb-4">
                        <div class="progress-bar bg-info" role="progressbar" style="width: 60%"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions Column (ditambah: Laporan & Statistik) -->
        <div class="col-lg-6 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Quick Actions</h6>
                </div>
                <div class="card-body">
                    <div class="text-center">
                        <i class="bi bi-fish text-primary mb-3" style="font-size: 3rem;"></i>
                    </div>
                    <p>Kelola sistem lelang ikan dengan mudah melalui menu berikut:</p>
                    <div class="row">
                        <div class="col-6 mb-2">
                            <a href="<?= site_url('/petugas/input-karcis-bakul') ?>" class="btn btn-primary btn-sm w-100">
                                <i class="bi bi-plus-circle me-1"></i>Input Bakul
                            </a>
                        </div>
                        <div class="col-6 mb-2">
                            <a href="<?= site_url('/petugas/input-karcis-pemilik-kapal') ?>" class="btn btn-success btn-sm w-100">
                                <i class="bi bi-plus-circle me-1"></i>Input Kapal
                            </a>
                        </div>
                        <div class="col-6 mb-2">
                            <a href="<?= site_url('/petugas/daftar-karcis-bakul') ?>" class="btn btn-info btn-sm w-100">
                                <i class="bi bi-list-ul me-1"></i>Daftar Bakul
                            </a>
                        </div>
                        <div class="col-6 mb-2">
                            <a href="<?= site_url('/petugas/daftar-karcis-pemilik-kapal') ?>" class="btn btn-warning btn-sm w-100">
                                <i class="bi bi-list-task me-1"></i>Daftar Kapal
                            </a>
                        </div>

                        <!-- TAMBAH MENU LAPORAN -->
                        <div class="col-6 mb-2">
                            <a href="<?= site_url('/laporan') ?>" class="btn btn-danger btn-sm w-100">
                                <i class="bi bi-bar-chart me-1"></i>Laporan
                            </a>
                        </div>
                        <div class="col-6 mb-2">
                            <a href="<?= site_url('/laporan/statistik') ?>" class="btn btn-secondary btn-sm w-100">
                                <i class="bi bi-graph-up me-1"></i>Statistik
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<style>
/* Exact styles from the reference image */
.text-gray-800 { color: #5a5c69 !important; }
.text-gray-300 { color: #dddfeb !important; }
.text-gray-400 { color: #b7b9cc !important; }
.text-gray-900 { color: #3a3b45 !important; }

.border-left-primary { border-left: 4px solid #4e73df !important; }
.border-left-success { border-left: 4px solid #1cc88a !important; }
.border-left-info { border-left: 4px solid #36b9cc !important; }
.border-left-warning { border-left: 4px solid #f6c23e !important; }

.card {
    border: 1px solid #e3e6f0;
    border-radius: 0.35rem;
}

.shadow {
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15) !important;
}

.card-header {
    background-color: #f8f9fc;
    border-bottom: 1px solid #e3e6f0;
}

.progress {
    height: 10px;
    border-radius: 5px;
}

.progress-bar {
    border-radius: 5px;
}

.chart-area, .chart-pie {
    position: relative;
}

.dropdown-menu {
    border: 1px solid #e3e6f0;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
}

.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.875rem;
}

.h3 { font-size: 1.75rem; }
.h5 { font-size: 1.25rem; }
.text-xs { font-size: 0.7rem; }

/* Custom spacing */
.mb-4 { margin-bottom: 1.5rem !important; }
.py-2 { padding-top: 0.5rem !important; padding-bottom: 0.5rem !important; }
.py-3 { padding-top: 1rem !important; padding-bottom: 1rem !important; }
</style>

<?= $this->include('layouts/footer') ?>
