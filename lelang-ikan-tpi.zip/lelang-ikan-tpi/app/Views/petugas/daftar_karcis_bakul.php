<?= $this->include('layouts/header') ?>

<div class="container mt-4">
    <!-- Header card -->
    <div class="card">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><i class="fas fa-list"></i> Daftar Karcis Bakul</h4>
            <div>
                <a href="<?= site_url('petugas/input-karcis-bakul') ?>" class="btn btn-light btn-sm">
                    <i class="fas fa-plus-circle"></i> Input Karcis Baru
                </a>
                <a href="<?= site_url('petugas') ?>" class="btn btn-secondary btn-sm">
                    <i class="fas fa-arrow-left"></i> Dashboard
                </a>
            </div>
        </div>

        <div class="card-body">
            <!-- Flash message -->
            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
            <?php endif; ?>
            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Nomor Karcis</th>
                            <th>Nama Bakul</th>
                            <th>Berat Ikan</th>
                            <th>Total Pembelian</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php if (!empty($karcis) && is_array($karcis)): ?>
                            <?php foreach ($karcis as $k): ?>
                                <?php
                                    // Fallbacks / kompatibilitas dengan kedua struktur data
                                    $nomor = $k['nomor_karcis'] ?? ($k['no_karcis'] ?? '-');
                                    $nama  = $k['nama_bakul'] ?? ($k['nama_bakul'] ?? '-');
                                    $berat = isset($k['berat_ikan']) ? (float)$k['berat_ikan'] : (isset($k['berat']) ? (float)$k['berat'] : 0);
                                    // total bisa berada di beberapa field
                                    $total = $k['total'] ?? $k['jumlah_pembelian'] ?? $k['jumlah_bayar'] ?? 0;
                                    // status fallback: jika ada field status pakai itu, kalau tidak, coba infer dari pembayaran
                                    if (isset($k['status'])) {
                                        $status = $k['status'];
                                    } else {
                                        // infer: jika jumlah_bayar >= total => verified, jika 0 => pending, else pending/partial
                                        $bayar = $k['jumlah_bayar'] ?? 0;
                                        if ($bayar <= 0) {
                                            $status = 'pending';
                                        } elseif ($bayar >= $total && $total > 0) {
                                            $status = 'verified';
                                        } else {
                                            $status = 'partial';
                                        }
                                    }
                                    // tanggal: prefer created_at, else tanggal_input, else -
                                    $tanggal_raw = $k['created_at'] ?? $k['tanggal_input'] ?? ($k['tanggal'] ?? null);
                                    $tanggal = $tanggal_raw ? date('d/m/Y', strtotime($tanggal_raw)) : '-';
                                ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= esc($nomor) ?></td>
                                    <td><?= esc($nama) ?></td>
                                    <td><?= number_format($berat, 2) ?> kg</td>
                                    <td>Rp <?= number_format((float)$total, 0, ',', '.') ?></td>
                                    <td>
                                        <?php if ($status == 'pending'): ?>
                                            <span class="badge bg-warning text-dark">Menunggu Verifikasi</span>
                                        <?php elseif ($status == 'verified'): ?>
                                            <span class="badge bg-success">Terverifikasi</span>
                                        <?php elseif ($status == 'partial'): ?>
                                            <span class="badge bg-info text-dark">Pembayaran Parsial</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger"><?= ucfirst(esc($status)) ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= $tanggal ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <i class="fas fa-inbox fa-2x text-muted mb-2"></i><br>
                                    Belum ada data karcis
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div> <!-- /.table-responsive -->
        </div> <!-- /.card-body -->
    </div> <!-- /.card -->
</div> <!-- /.container -->

<?= $this->include('layouts/footer') ?>
