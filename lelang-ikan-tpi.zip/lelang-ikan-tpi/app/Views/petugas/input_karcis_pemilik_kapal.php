<!DOCTYPE html>
<html>
<head>
    <title>Input Karcis Pemilik Kapal - Sistem Lelang Ikan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url('petugas') ?>">
                <i class="fas fa-fish"></i> Sistem Lelang Ikan
            </a>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="card">
            <div class="card-header bg-success text-white">
                <h4 class="mb-0"><i class="fas fa-ship"></i> Input Karcis Pemilik Kapal</h4>
            </div>
            <div class="card-body">
                <?php if (session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i> 
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>
                
                <?php if (session()->getFlashdata('success')): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> 
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?= base_url('working-input/pemilik-kapal') ?>">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-ticket"></i> Nomor Karcis</label>
                                <input type="text" name="nomor_karcis" class="form-control" required 
                                       placeholder="Contoh: KPL-001-2401">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-user"></i> Nama Nelayan</label>
                                <input type="text" name="nama_nelayan" class="form-control" required 
                                       placeholder="Nama pemilik kapal/nelayan">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-map-marker-alt"></i> Alamat</label>
                                <textarea name="alamat" class="form-control" rows="3" 
                                          placeholder="Alamat nelayan"></textarea>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-weight"></i> Berat Ikan (kg)</label>
                                <input type="number" step="0.01" name="berat_ikan" class="form-control" required 
                                       placeholder="Contoh: 350.8">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-ticket"></i> Jumlah Karcis</label>
                                <input type="number" name="jumlah_karcis" class="form-control" required 
                                       placeholder="Jumlah karcis">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-money-bill"></i> Jumlah Penjualan (Rp)</label>
                                <input type="text" name="jumlah_penjualan" class="form-control" required 
                                       placeholder="Contoh: 8770000">
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="<?= base_url('petugas') ?>" class="btn btn-secondary me-md-2">
                            <i class="fas fa-arrow-left"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-save"></i> Simpan Karcis
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-header bg-info text-white">
                <h6 class="mb-0"><i class="fas fa-info-circle"></i> Contoh Data untuk Testing</h6>
            </div>
            <div class="card-body">
                <p><strong>Data Sample:</strong></p>
                <ul>
                    <li>Nomor Karcis: <code>KPL-001-2401</code></li>
                    <li>Nama Nelayan: <code>Ahmad Fauzi</code></li>
                    <li>Alamat: <code>Desa Bahari, Kec. Soropia</code></li>
                    <li>Berat Ikan: <code>350.8</code> kg</li>
                    <li>Jumlah Karcis: <code>4</code></li>
                    <li>Jumlah Penjualan: <code>8770000</code></li>
                </ul>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>