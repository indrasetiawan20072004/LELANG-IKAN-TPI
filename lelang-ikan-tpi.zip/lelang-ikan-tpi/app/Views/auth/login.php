<!DOCTYPE html>
<html>
<head>
    <title>Login - Sistem Lelang Ikan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Login Sistem Lelang Ikan</h3>
                    </div>
                    <div class="card-body">
                        <?php if (session()->getFlashdata('error')): ?>
                            <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
                        <?php endif; ?>
                        
                        <!-- PASTIKAN ACTIONNYA BENAR -->
                        <form method="post" action="<?= base_url('auth/login') ?>">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required 
                                       value="<?= old('username') ?>">
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Login</button>
                        </form>
                        
                        <div class="mt-3 text-center">
                            <p>Default login:</p>
                            <p>Petugas TPI - username: <strong>petugas</strong>, password: <strong>petugas123</strong></p>
                            <p>Admin HNSI - username: <strong>admin</strong>, password: <strong>admin123</strong></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>