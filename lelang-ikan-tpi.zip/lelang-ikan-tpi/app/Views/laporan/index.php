<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?> - Sistem Lelang Ikan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .table-responsive { max-height: 600px; }
        .card-header { background-color: #0d6efd; color: white; }
        .btn-export { margin-right: 5px; }
        .stat-card { border-left: 4px solid #0d6efd; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-fish"></i> Sistem Laporan Hasil Lelang Ikan
            </a>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Card Statistik -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <h5 class="card-title">Total Lelang</h5>
                        <h3 class="text-primary"><?= $total_lelang ?? 0 ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <h5 class="card-title">Total Berat</h5>
                        <h3 class="text-success"><?= number_format($total_berat ?? 0, 2) ?> kg</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <h5 class="card-title">Total Nilai</h5>
                        <h3 class="text-danger">Rp <?= number_format($total_nilai ?? 0, 0, ',', '.') ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card">
                    <div class="card-body">
                        <h5 class="card-title">Rata-rata Harga</h5>
                        <h3 class="text-warning">Rp <?= number_format($avg_harga ?? 0, 0, ',', '.') ?>/kg</h3>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card Utama -->
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0"><i class="fas fa-list"></i> <?= $title ?></h4>
            </div>
            <div class="card-body">
                <!-- Filter Form -->
                <form method="get" class="row g-3 mb-4 p-3 border rounded">
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Mulai</label>
                        <input type="date" name="start_date" class="form-control" value="<?= $startDate ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Tanggal Selesai</label>
                        <input type="date" name="end_date" class="form-control" value="<?= $endDate ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Jenis Ikan</label>
                        <select name="jenis_ikan" class="form-select">
                            <option value="">Semua Jenis</option>
                            <option value="Tuna" <?= ($jenisIkan == 'Tuna') ? 'selected' : '' ?>>Tuna</option>
                            <option value="Cakalang" <?= ($jenisIkan == 'Cakalang') ? 'selected' : '' ?>>Cakalang</option>
                            <option value="Tongkol" <?= ($jenisIkan == 'Tongkol') ? 'selected' : '' ?>>Tongkol</option>
                            <option value="Kakap" <?= ($jenisIkan == 'Kakap') ? 'selected' : '' ?>>Kakap</option>
                            <option value="Kerapu" <?= ($jenisIkan == 'Kerapu') ? 'selected' : '' ?>>Kerapu</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">&nbsp;</label>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter"></i> Filter Data
                            </button>
                            <a href="<?= base_url('laporan') ?>" class="btn btn-secondary">
                                <i class="fas fa-refresh"></i> Reset
                            </a>
                        </div>
                    </div>
                </form>

                <!-- Tombol Export -->
                <div class="d-flex justify-content-between mb-3">
                    <div>
                        <a href="<?= base_url('laporan/exportExcel') . '?start_date=' . $startDate . '&end_date=' . $endDate . '&jenis_ikan=' . $jenisIkan ?>" 
                           class="btn btn-success btn-export">
                            <i class="fas fa-file-excel"></i> Export Excel
                        </a>
                        <a href="<?= base_url('laporan/statistik') ?>" class="btn btn-info btn-export">
                            <i class="fas fa-chart-bar"></i> Lihat Statistik
                        </a>
                    </div>
                    <div>
                        <span class="badge bg-primary">Total Data: <?= count($lelang) ?></span>
                    </div>
                </div>

                <!-- Table -->
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th width="50">No</th>
                                <th>Jenis Ikan</th>
                                <th width="100">Tanggal</th>
                                <th>Lokasi Pelelangan</th>
                                <th width="120">Berat (kg)</th>
                                <th width="140">Harga Awal/kg</th>
                                <th width="140">Harga Akhir/kg</th>
                                <th width="160">Total Nilai</th>
                                <th>Perusahaan Pemenang</th>
                                <th width="100">Jumlah Peserta</th>
                                <th width="120">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($lelang)): ?>
                            <tr>
                                <td colspan="11" class="text-center text-muted py-4">
                                    <i class="fas fa-inbox fa-2x mb-2"></i><br>
                                    Tidak ada data lelang untuk ditampilkan
                                </td>
                            </tr>
                            <?php else: ?>
                                <?php $no = 1; ?>
                                <?php foreach ($lelang as $item): ?>
                                <tr>
                                    <td class="text-center"><?= $no++ ?></td>
                                    <td>
                                        <strong><?= $item['jenis_ikan'] ?></strong>
                                        <?php if ($item['status_lelang'] == 'berlangsung'): ?>
                                            <span class="badge bg-warning float-end">Berlangsung</span>
                                        <?php elseif ($item['status_lelang'] == 'selesai'): ?>
                                            <span class="badge bg-success float-end">Selesai</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary float-end">Draft</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('d/m/Y', strtotime($item['tanggal_lelang'])) ?></td>
                                    <td><?= $item['lokasi_pelelangan'] ?></td>
                                    <td class="text-end"><?= number_format($item['berat_total'], 2, ',', '.') ?> kg</td>
                                    <td class="text-end">Rp <?= number_format($item['harga_awal_per_kg'], 0, ',', '.') ?></td>
                                    <td class="text-end">Rp <?= number_format($item['harga_akhir_per_kg'], 0, ',', '.') ?></td>
                                    <td class="text-end"><strong>Rp <?= number_format($item['total_nilai_lelang'], 0, ',', '.') ?></strong></td>
                                    <td>
                                        <?php if ($item['pemenang_lelang']): ?>
                                            <span class="badge bg-success"><?= $item['pemenang_lelang'] ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-info"><?= $item['jumlah_peserta'] ?> peserta</span>
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group btn-group-sm" role="group">
                                            <a href="<?= base_url('laporan/detail/' . $item['id_lelang']) ?>" 
                                               class="btn btn-info" title="Detail">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?= base_url('laporan/exportPDF/' . $item['id_lelang']) ?>" 
                                               class="btn btn-danger" title="Export PDF">
                                                <i class="fas fa-file-pdf"></i>
                                            </a>
                                            <a href="<?= base_url('laporan/cetak/' . $item['id_lelang']) ?>" 
                                               class="btn btn-warning" title="Cetak" target="_blank">
                                                <i class="fas fa-print"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <footer class="mt-5 py-3 bg-light">
        <div class="container text-center">
            <small class="text-muted">
                &copy; <?= date('Y') ?> Sistem Laporan Hasil Lelang Ikan - Developed with <i class="fas fa-heart text-danger"></i>
            </small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto set tanggal akhir sama dengan tanggal mulai jika tanggal mulai diisi
        document.querySelector('input[name="start_date"]').addEventListener('change', function() {
            const endDateField = document.querySelector('input[name="end_date"]');
            if (!endDateField.value) {
                endDateField.value = this.value;
            }
        });
    </script>
</body>
</html>