<?php
namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = ['username', 'password', 'role', 'tpi_id'];
    protected $useTimestamps = false; // Karena tidak ada created_at/updated_at
}