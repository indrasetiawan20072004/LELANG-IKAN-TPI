<?php
namespace App\Models;

use CodeIgniter\Model;

class KarcisBakulModel extends Model
{
    protected $table      = 'karcis_bakul';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'nomor_karcis', 'nama_bakul', 'alamat', 'berat_ikan', 'jumlah_karcis',
        'jumlah_pembelian', 'jasa_lelang', 'lain_lain', 'total', 'jumlah_bayar',
        'created_by', 'status'
    ];

    // Aktifkan timestamp otomatis hanya untuk created_at
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = ''; // Tidak pakai updated_at

    // Rules untuk validasi data
    protected $validationRules = [
        'nomor_karcis'      => 'required|is_unique[karcis_bakul.nomor_karcis]',
        'nama_bakul'        => 'required',
        'alamat'            => 'required',
        'berat_ikan'        => 'required|numeric',
        'jumlah_karcis'     => 'required|numeric',
        'jumlah_pembelian'  => 'required|numeric',
        'jasa_lelang'       => 'required|numeric',
        'total'             => 'required|numeric',
        'jumlah_bayar'      => 'required|numeric'
    ];

    // Pesan error custom
    protected $validationMessages = [
        'nomor_karcis' => [
            'required'  => 'Nomor karcis wajib diisi.',
            'is_unique' => 'Nomor karcis ini sudah digunakan.'
        ],
        'nama_bakul' => [
            'required' => 'Nama bakul wajib diisi.'
        ],
        'alamat' => [
            'required' => 'Alamat wajib diisi.'
        ],
        'berat_ikan' => [
            'required' => 'Berat ikan wajib diisi.',
            'numeric'  => 'Berat ikan harus berupa angka.'
        ],
        'jumlah_karcis' => [
            'required' => 'Jumlah karcis wajib diisi.',
            'numeric'  => 'Jumlah karcis harus berupa angka.'
        ],
        'jumlah_pembelian' => [
            'required' => 'Jumlah pembelian wajib diisi.',
            'numeric'  => 'Jumlah pembelian harus berupa angka.'
        ],
        'jasa_lelang' => [
            'required' => 'Jasa lelang wajib diisi.',
            'numeric'  => 'Jasa lelang harus berupa angka.'
        ],
        'total' => [
            'required' => 'Total wajib diisi.',
            'numeric'  => 'Total harus berupa angka.'
        ],
        'jumlah_bayar' => [
            'required' => 'Jumlah bayar wajib diisi.',
            'numeric'  => 'Jumlah bayar harus berupa angka.'
        ]
    ];
}
