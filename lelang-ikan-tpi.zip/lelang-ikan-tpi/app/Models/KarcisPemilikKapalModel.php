<?php 
namespace App\Models;

use CodeIgniter\Model;

class KarcisPemilikKapalModel extends Model
{
    protected $table = 'karcis_pemilik_kapal'; // Nama tabel
    protected $primaryKey = 'id'; // Primary key

    // Kolom yang bisa diisi (fillable)
    protected $allowedFields = [
        'nomor_karcis', 
        'nama_nelayan', 
        'alamat', 
        'berat_ikan', 
        'jumlah_karcis', 
        'jumlah_penjualan', 
        'jasa_lelang', 
        'lain_lain', 
        'total', 
        'jumlah_dibayar', 
        'created_by', 
        'status'
    ];

    // Aktifkan otomatis timestamps
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Opsional: jika ingin menonaktifkan validasi sementara
    protected $skipValidation = true;
}
