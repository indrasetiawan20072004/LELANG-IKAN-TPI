<?php 
namespace App\Controllers;

class Admin extends BaseController
{
    public function index()
    {
        // Tulis log saat fungsi dipanggil
        $this->writeLog("=== Admin::index accessed ===");
        $this->writeLog("Session data: " . print_r(session()->get(), true));
        
        // Cek login
        if (!session()->get('logged_in')) {
            $this->writeLog("❌ NOT LOGGED IN - Redirect to login");
            return redirect()->to('/auth/login');
        }
        
        // Ambil nama (fallback ke username jika nama_lengkap tidak ada)
        $nama = session()->get('nama_lengkap') ?: session()->get('username');
        $this->writeLog("✅ User logged in: " . $nama);
        
        $data = [
            'title' => 'Dashboard Admin',
            'user' => [
                'nama' => $nama,
                'role' => session()->get('role')
            ]
        ];
        
        return view('admin/dashboard', $data);
    }

    public function laporan()
    {
        $this->writeLog("=== Admin::laporan accessed ===");

        // Cek login
        if (!session()->get('logged_in')) {
            $this->writeLog("❌ NOT LOGGED IN - Redirect to login (laporan)");
            return redirect()->to('/auth/login');
        }

        $this->writeLog("✅ Redirect ke /laporan");
        return redirect()->to('/laporan');
    }

    public function cetakLaporan()
    {
        $this->writeLog("=== Admin::cetakLaporan accessed ===");

        // Cek login
        if (!session()->get('logged_in')) {
            $this->writeLog("❌ NOT LOGGED IN - Redirect to login (cetakLaporan)");
            return redirect()->to('/auth/login');
        }

        $this->writeLog("✅ Redirect ke /laporan/exportExcel");
        return redirect()->to('/laporan/exportExcel');
    }
    
    private function writeLog($message)
    {
        $logFile = WRITEPATH . 'logs/admin_debug.log';
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND | LOCK_EX);
    }
}
