<?php
namespace App\Controllers;

class WorkingInput extends BaseController
{
    public function bakul()
    {
        // Simple approach - langsung proses tanpa validation
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST)) {
            echo "<h1>Working Input - Processing</h1>";

            // Ambil raw POST (aman untuk debug)
            $raw = $_POST;

            // Proses cleaning angka (hapus titik/koma ribuan)
            $clean_number = function($val, $default = 0) {
                if (!isset($val) || $val === '') return $default;
                // Hapus titik dan koma (jika format lokal pakai . sebagai ribuan dan , sebagai desimal,
                // strategi ini menghilangkan simbol sehingga hasilnya integer-like; sesuai kode asli)
                $only = str_replace(['.', ','], '', $val);
                // Jika hasil kosong, return default
                if ($only === '') return $default;
                // cast ke float
                return (float) $only;
            };

            $data = [
                'nama_bakul' => isset($raw['nama_bakul']) ? $raw['nama_bakul'] : '',
                'alamat' => isset($raw['alamat']) ? $raw['alamat'] : '',
                'berat_ikan' => isset($raw['berat_ikan']) && $raw['berat_ikan'] !== '' ? (float) $raw['berat_ikan'] : 0.0,
                'jumlah_karcis' => isset($raw['jumlah_karcis']) && $raw['jumlah_karcis'] !== '' ? (int) $raw['jumlah_karcis'] : 0,
                'jumlah_pembelian' => $clean_number($raw['jumlah_pembelian'] ?? 0),
                'jasa_lelang' => $clean_number($raw['jasa_lelang'] ?? 0),
                'lain_lain' => $clean_number($raw['lain_lain'] ?? 0),
                'total' => $clean_number($raw['total'] ?? 0),
                'jumlah_bayar' => $clean_number($raw['jumlah_bayar'] ?? 0)
            ];

            // DEBUG: Cek kenapa total jadi 0
            echo "<h3>Debug Total:</h3>";
            echo "Raw total from POST: " . htmlspecialchars($raw['total'] ?? 'NULL') . "<br>";
            echo "After processing (cleaned) total: " . $data['total'] . "<br>";

            // Jika total masih 0, hitung manual dari komponennya
            if ($data['total'] == 0) {
                $calculated = $data['jumlah_pembelian'] + $data['jasa_lelang'] + $data['lain_lain'];
                $data['total'] = $calculated;
                echo "Calculated total (jumlah_pembelian + jasa_lelang + lain_lain): " . $data['total'] . "<br>";
            }

            echo "<h3>Data yang disimpan:</h3>";
            echo "<pre>";
            print_r($data);
            echo "</pre>";

            // Pakai native MySQL untuk memastikan work
            $host = 'localhost';
            $user = 'root';
            $password = '';
            $database = 'tpi_lelang';

            $conn = mysqli_connect($host, $user, $password, $database);

            if (!$conn) {
                die("<div style='color: red;'>❌ Connection failed: " . mysqli_connect_error() . "</div>");
            }

            $sql = "INSERT INTO karcis_bakul (nama_bakul, alamat, berat_ikan, jumlah_karcis, jumlah_pembelian, jasa_lelang, lain_lain, total, jumlah_bayar) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = mysqli_prepare($conn, $sql);
            if (!$stmt) {
                echo "<div style='color: red; font-weight: bold;'>❌ Prepare failed: " . mysqli_error($conn) . "</div>";
            } else {
                // Parameter types:
                // s - string (nama_bakul)
                // s - string (alamat)
                // d - double/float (berat_ikan)
                // i - integer (jumlah_karcis)
                // d - double (jumlah_pembelian)
                // d - double (jasa_lelang)
                // d - double (lain_lain)
                // d - double (total)
                // d - double (jumlah_bayar)
                mysqli_stmt_bind_param($stmt, "ssdiddddd",
                    $data['nama_bakul'],
                    $data['alamat'],
                    $data['berat_ikan'],
                    $data['jumlah_karcis'],
                    $data['jumlah_pembelian'],
                    $data['jasa_lelang'],
                    $data['lain_lain'],
                    $data['total'],
                    $data['jumlah_bayar']
                );

                if (mysqli_stmt_execute($stmt)) {
                    $insertId = mysqli_insert_id($conn);
                    echo "<div style='color: green; font-weight: bold; padding: 10px; border: 2px solid green;'>";
                    echo "✅ SUCCESS! Karcis bakul berhasil disimpan. ID: " . $insertId;
                    echo "</div>";

                    // Redirect manual setelah 3 detik
                    echo "<script>
                        setTimeout(function() {
                            window.location.href = '/lelang-ikan-tpi/petugas/daftar-karcis-bakul';
                        }, 3000);
                    </script>";

                    echo "<p>Redirecting ke daftar karcis dalam 3 detik...</p>";

                } else {
                    echo "<div style='color: red; font-weight: bold;'>❌ FAILED: " . mysqli_stmt_error($stmt) . "</div>";
                }

                mysqli_stmt_close($stmt);
            }

            mysqli_close($conn);

            echo "<br><a href='/lelang-ikan-tpi/petugas/input-karcis-bakul' class='btn btn-primary'>Kembali ke Form</a>";

        } else {
            echo "Tidak ada data yang dikirim";
        }
    }

public function pemilikKapal()
{
    // Simple approach - langsung proses tanpa validation
    if ($_POST) {
        
        // Process data
        $data = [
            'no_karcis' => $_POST['nomor_karcis'],
            'nama_pemilik' => $_POST['nama_nelayan'],
            'nama_kapal' => $_POST['nama_nelayan'] . ' - Kapal',
            'tanggal' => date('Y-m-d'),
            'jenis_ikan' => 'Campuran',
            'berat' => (float) $_POST['berat_ikan'],
            'harga' => (float) str_replace(['.', ','], '', $_POST['jumlah_penjualan']),
            'status_verifikasi' => 'pending',
            'petugas_id' => session()->get('user_id')
        ];
        
        // Pakai native MySQL untuk memastikan work
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $database = 'tpi_lelang';
        
        $conn = mysqli_connect($host, $user, $password, $database);
        
        if (!$conn) {
            // Redirect back dengan error
            return redirect()->to('/petugas/input-karcis-pemilik-kapal')->with('error', 'Koneksi database gagal: ' . mysqli_connect_error());
        }
        
        $sql = "INSERT INTO karcis_pemilik_kapal (no_karcis, nama_pemilik, nama_kapal, tanggal, jenis_ikan, berat, harga, status_verifikasi, petugas_id) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssssddsi", 
            $data['no_karcis'],
            $data['nama_pemilik'],
            $data['nama_kapal'],
            $data['tanggal'],
            $data['jenis_ikan'],
            $data['berat'],
            $data['harga'],
            $data['status_verifikasi'],
            $data['petugas_id']
        );
        
        if (mysqli_stmt_execute($stmt)) {
            $insertId = mysqli_insert_id($conn);
            mysqli_close($conn);
            
            // REDIRECT KE HALAMAN SUKSES
            return redirect()->to('/petugas/input-sukses-kapal')->with('success_data', [
                'id' => $insertId,
                'nama_pemilik' => $data['nama_pemilik'],
                'no_karcis' => $data['no_karcis'],
                'harga' => $data['harga']
            ]);
            
        } else {
            $error = mysqli_error($conn);
            mysqli_close($conn);
            return redirect()->to('/petugas/input-karcis-pemilik-kapal')->with('error', 'Gagal menyimpan: ' . $error);
        }
    }
    
    return redirect()->to('/petugas/input-karcis-pemilik-kapal');
}

}
