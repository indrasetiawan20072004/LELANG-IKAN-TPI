<?php 
namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function login()
    {
        // Log start (avoid logging sensitive payloads)
        $this->writeLog("=== LOGIN PAGE ACCESSED ===");
        $this->writeLog("Request Method: " . $this->request->getMethod());

        if ($this->request->getMethod() === 'POST') {
            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password');

            // Log only the username and that a POST was received — do NOT log the password.
            $this->writeLog("POST login attempt for username: " . ($username ?: '[empty]'));

            $userModel = new UserModel();
            $user = $userModel->where('username', $username)->first();

            if ($user) {
                $this->writeLog("User found: " . $user['username']);

                $dbPass = isset($user['password']) ? $user['password'] : null;

                $passwordMatch = false;

                // Prefer secure check with password_verify (for hashed passwords)
                if (!empty($dbPass) && (strpos($dbPass, '$2y$') === 0 || strpos($dbPass, '$argon2') === 0)) {
                    if (password_verify($password, $dbPass)) {
                        $passwordMatch = true;
                    }
                } else {
                    // Fallback for legacy plaintext-stored passwords (NOT recommended).
                    // If plaintext matches, re-hash into a secure algorithm and update DB.
                    if ($dbPass !== null && $password === $dbPass) {
                        $passwordMatch = true;

                        // Rehash and update DB so future checks use password_verify
                        $newHash = password_hash($password, PASSWORD_DEFAULT);
                        try {
                            $userModel->update($user['id'], ['password' => $newHash]);
                            $this->writeLog("Legacy plaintext password detected — migrated to hashed password for user: " . $user['username']);
                        } catch (\Exception $e) {
                            // If update fails, log non-sensitive information about the failure
                            $this->writeLog("Failed to migrate plaintext password for user: " . $user['username'] . ". Error: " . $e->getMessage());
                        }
                    }
                }

                if ($passwordMatch) {
                    $this->writeLog("✅ Authentication SUCCESS for user: " . $user['username']);

                    // Set session
                    session()->set('user_id', $user['id']);
                    session()->set('username', $user['username']);
                    session()->set('nama_lengkap', isset($user['nama_lengkap']) ? $user['nama_lengkap'] : '');
                    session()->set('role', isset($user['role']) ? $user['role'] : 'user');
                    session()->set('logged_in', true);

                    $this->writeLog("✅ Session SET - Role: " . session()->get('role'));

                    // Redirect berdasarkan role
                    if (session()->get('role') === 'admin') {
                        $this->writeLog("Redirecting to /admin");
                        return redirect()->to(base_url('admin'));
                    } else {
                        $this->writeLog("Redirecting to /petugas");
                        return redirect()->to(base_url('petugas'));
                    }
                } else {
                    $this->writeLog("❌ Authentication FAILED for user: " . $user['username']);
                    return redirect()->back()->with('error', 'Password salah!');
                }
            } else {
                $this->writeLog("❌ User NOT FOUND: " . ($username ?: '[empty]'));
                return redirect()->back()->with('error', 'User tidak ditemukan!');
            }
        }

        $this->writeLog("Showing login form");
        return view('auth/login');
    }

    private function writeLog($message)
    {
        // Simple logger that avoids writing sensitive data. Keep messages concise.
        $logFile = WRITEPATH . 'logs/auth_debug.log';
        $timestamp = date('Y-m-d H:i:s');
        // Ensure directory exists (usually WRITEPATH/logs exists in CI4)
        @file_put_contents($logFile, "[" . $timestamp . "] " . $message . PHP_EOL, FILE_APPEND | LOCK_EX);
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/auth/login');
    }

    public function index()
    {
        return $this->login();
    }
}
