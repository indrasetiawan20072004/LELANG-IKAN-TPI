<?php namespace App\Controllers;

use App\Models\UserModel;

class Debug extends BaseController
{
    public function index()
    {
        echo "<h1>Debug System - Login Test</h1>";
        
        // Test 1: Basic CI4
        echo "<p>1. CodeIgniter 4: <span style='color:green'>✓ RUNNING</span></p>";
        
        // Test 2: Database Connection
        try {
            $db = db_connect();
            $db->query('SELECT 1');
            echo "<p>2. Database Connection: <span style='color:green'>✓ SUCCESS</span></p>";
        } catch (\Exception $e) {
            echo "<p>2. Database Connection: <span style='color:red'>✗ FAILED - " . $e->getMessage() . "</span></p>";
        }
        
        // Test 3: Check Users in Database
        try {
            $userModel = new UserModel();
            $users = $userModel->findAll();
            echo "<p>3. Users in Database: <span style='color:green'>✓ " . count($users) . " users found</span></p>";
            
            // Show users
            echo "<pre>Users: " . print_r($users, true) . "</pre>";
            
        } catch (\Exception $e) {
            echo "<p>3. User Model: <span style='color:red'>✗ FAILED - " . $e->getMessage() . "</span></p>";
        }
        
        // Test 4: Test Login Functionality
        echo "<h3>Test Login Manual:</h3>";
        echo "<form method='post' action='/debug/test-login'>";
        echo "Username: <input type='text' name='username' value='admin'><br>";
        echo "Password: <input type='password' name='password' value='admin123'><br>";
        echo "<input type='submit' value='Test Login'>";
        echo "</form>";
        
        echo "<hr>";
        echo "<p><a href='/auth/login' class='btn btn-primary'>Kembali ke Login Page</a></p>";
    }
    
    public function testLogin()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        
        echo "<h2>Login Test Result</h2>";
        echo "<p>Username: $username</p>";
        echo "<p>Password: $password</p>";
        
        $userModel = new UserModel();
        $user = $userModel->where('username', $username)->first();
        
        if ($user) {
            echo "<p>User found: <span style='color:green'>✓</span></p>";
            echo "<pre>User data: " . print_r($user, true) . "</pre>";
            
            // Test password verification
            if (($username === 'admin' && $password === 'admin123') || 
                ($username === 'petugas' && $password === 'petugas123')) {
                echo "<p>Password verification: <span style='color:green'>✓ SUCCESS</span></p>";
            } else {
                echo "<p>Password verification: <span style='color:red'>✗ FAILED</span></p>";
            }
        } else {
            echo "<p>User not found: <span style='color:red'>✗</span></p>";
        }
        
        echo "<p><a href='/debug'>Kembali ke Debug</a></p>";
    }
    
    public function testRoute()
    {
        return "Test berhasil! Sistem berjalan.";
    }
}