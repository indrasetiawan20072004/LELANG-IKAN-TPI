<?php namespace App\Controllers;

use App\Models\KarcisBakulModel;
use App\Models\KarcisPemilikKapalModel;

class Petugas extends BaseController
{
    protected $karcisBakulModel;
    protected $karcisPemilikKapalModel;

    public function __construct()
    {
        $this->karcisBakulModel = new KarcisBakulModel();
        $this->karcisPemilikKapalModel = new KarcisPemilikKapalModel();
    }

    /**
     * Helper kecil untuk cek autentikasi (mengembalikan redirect jika tidak login)
     */
    protected function ensureLoggedIn()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login');
        }
        return null;
    }

    public function index()
    {
        // cek login
        if ($resp = $this->ensureLoggedIn()) {
            return $resp;
        }

        $data = [
            'title' => 'Dashboard Petugas TPI',
            'nama_lengkap' => session()->get('nama_lengkap')
        ];
        return view('petugas/dashboard', $data);
    }

    // === INPUT KARCIS BAKUL ===
    public function inputKarcisBakul()
    {
        // cek login
        if ($resp = $this->ensureLoggedIn()) {
            return $resp;
        }

        if ($this->request->getMethod() === 'POST') {
            // DEBUG: Tampilkan data yang diterima (log)
            $postData = $this->request->getPost();
            $this->writeLog("=== INPUT KARCIS BAKUL - POST ===");
            $this->writeLog("POST Data: " . print_r($postData, true));

            // Siapkan data sesuai struktur table karcis_bakul
            $data = [
                'nama_bakul'       => $this->request->getPost('nama_bakul'),
                'alamat'           => $this->request->getPost('alamat'),
                'berat_ikan'       => $this->cleanNumber($this->request->getPost('berat_ikan')),
                'jumlah_karcis'    => $this->cleanNumber($this->request->getPost('jumlah_karcis')),
                'jumlah_pembelian' => $this->cleanNumber($this->request->getPost('jumlah_pembelian')),
                'jasa_lelang'      => $this->cleanNumber($this->request->getPost('jasa_lelang')),
                'lain_lain'        => $this->cleanNumber($this->request->getPost('lain_lain') ?? 0),
                'total'            => $this->cleanNumber($this->request->getPost('total')),
                'jumlah_bayar'     => $this->cleanNumber($this->request->getPost('jumlah_bayar')),
                // metadata
                'created_by'       => session()->get('user_id'),
                'created_at'       => date('Y-m-d H:i:s')
            ];

            $this->writeLog("Processed Data: " . print_r($data, true));

            try {
                if ($this->karcisBakulModel->save($data)) {
                    $insertedID = $this->karcisBakulModel->getInsertID();
                    $this->writeLog("✅ SUCCESS: Karcis bakul disimpan. Insert ID: " . $insertedID);
                    return redirect()->to('/petugas/daftar-karcis-bakul')->with('success', 'Karcis bakul berhasil disimpan!');
                } else {
                    $errors = $this->karcisBakulModel->errors();
                    $this->writeLog("❌ FAILED: Gagal menyimpan karcis bakul. Errors: " . print_r($errors, true));
                    if (method_exists($this->karcisBakulModel, 'getLastQuery')) {
                        $this->writeLog("Last Query: " . $this->karcisBakulModel->getLastQuery());
                    }
                    return redirect()->back()->withInput()->with('error', 'Gagal menyimpan karcis bakul! Silakan cek data Anda.');
                }
            } catch (\Exception $e) {
                $this->writeLog("❌ EXCEPTION saat simpan karcis bakul: " . $e->getMessage());
                $this->writeLog("Stack Trace: " . $e->getTraceAsString());

                // Coba manual insert sebagai upaya pemulihan (opsional)
                try {
                    $db = db_connect();
                    $manualResult = $db->table('karcis_bakul')->insert($data);
                    if ($manualResult) {
                        $manualId = $db->insertID();
                        $this->writeLog("✅ MANUAL INSERT SUCCESS! ID: " . $manualId);
                        return redirect()->to('/petugas/daftar-karcis-bakul')->with('success', 'Karcis bakul berhasil disimpan (manual)!');
                    } else {
                        $this->writeLog("❌ MANUAL INSERT FAILED: " . print_r($db->error(), true));
                    }
                } catch (\Exception $e2) {
                    $this->writeLog("❌ MANUAL INSERT EXCEPTION: " . $e2->getMessage());
                }

                return redirect()->back()->withInput()->with('error', 'Error: ' . $e->getMessage());
            }
        }

        $data = ['title' => 'Input Karcis Bakul'];
        return view('petugas/input_karcis_bakul', $data);
    }

    // === INPUT KARCIS PEMILIK KAPAL ===
    public function inputKarcisPemilikKapal()
    {
        if ($this->request->getMethod() === 'POST') {
            // Data dari form
            $data = [
                'no_karcis' => $this->request->getPost('nomor_karcis'),
                'nama_pemilik' => $this->request->getPost('nama_nelayan'),
                'nama_kapal' => $this->request->getPost('nama_nelayan') . ' - Kapal',
                'tanggal' => date('Y-m-d'),
                'jenis_ikan' => 'Campuran',
                'berat' => (float) $this->request->getPost('berat_ikan'),
                'harga' => (float) str_replace(['.', ','], '', $this->request->getPost('jumlah_penjualan')),
                'status_verifikasi' => 'pending',
                'petugas_id' => session()->get('user_id')
            ];

            // MANUAL INSERT
            $db = db_connect();
            $result = $db->table('karcis_pemilik_kapal')->insert($data);

            if ($result) {
                $insertId = $db->insertID();
                return redirect()->to('/petugas/daftar-karcis-pemilik-kapal')->with('success', 'Karcis pemilik kapal berhasil disimpan! ID: ' . $insertId);
            } else {
                $error = $db->error();
                return redirect()->back()->with('error', 'Gagal menyimpan karcis pemilik kapal! Error: ' . $error['message']);
            }
        }

        $data = ['title' => 'Input Karcis Pemilik Kapal'];
        return view('petugas/input_karcis_pemilik_kapal', $data);
    }

    // === DAFTAR KARCIS BAKUL ===
    public function daftarKarcisBakul()
{
    // Pakai native query tanpa filter created_by
    $host = 'localhost';
    $user = 'root'; 
    $password = '';
    $database = 'tpi_lelang';
    
    $conn = mysqli_connect($host, $user, $password, $database);
    $karcis = [];
    
    if ($conn) {
        // HAPUS WHERE created_by karena column tidak ada
        $result = mysqli_query($conn, "SELECT * FROM karcis_bakul ORDER BY id_bakul DESC");
        while ($row = mysqli_fetch_assoc($result)) {
            $karcis[] = $row;
        }
        mysqli_close($conn);
    }
    
    $data = [
        'title' => 'Daftar Karcis Bakul',
        'karcis' => $karcis
    ];
    return view('petugas/daftar_karcis_bakul', $data);
}


    // === DAFTAR KARCIS PEMILIK KAPAL ===
    public function daftarKarcisPemilikKapal()
{
    // Pakai native query
    $host = 'localhost';
    $user = 'root'; 
    $password = '';
    $database = 'tpi_lelang';
    
    $conn = mysqli_connect($host, $user, $password, $database);
    $karcis = [];
    
    if ($conn) {
        // HAPUS WHERE petugas_id atau ganti dengan kondisi yang sesuai
        $result = mysqli_query($conn, "SELECT * FROM karcis_pemilik_kapal ORDER BY id DESC");
        while ($row = mysqli_fetch_assoc($result)) {
            $karcis[] = $row;
        }
        mysqli_close($conn);
    }
    
    $data = [
        'title' => 'Daftar Karcis Pemilik Kapal',
        'karcis' => $karcis
    ];
    return view('petugas/daftar_karcis_pemilik_kapal', $data);
}

public function inputSukses()
{
    $successData = session()->getFlashdata('success_data');
    
    if (!$successData) {
        return redirect()->to('/petugas/input-karcis-bakul');
    }
    
    $data = [
        'title' => 'Input Berhasil',
        'success_data' => $successData
    ];
    
    return view('petugas/input_sukses', $data);
}


public function inputSuksesKapal()
{
    $successData = session()->getFlashdata('success_data');
    
    if (!$successData) {
        return redirect()->to('/petugas/input-karcis-pemilik-kapal');
    }
    
    $data = [
        'title' => 'Input Berhasil',
        'success_data' => $successData
    ];
    
    return view('petugas/input_sukses_kapal', $data);
}


    /**
     * Fungsi uji untuk menyimpan data Karcis Bakul (digunakan saat development/testing)
     */
    public function testInputBakul()
    {
        if ($resp = $this->ensureLoggedIn()) {
            return $resp;
        }

        $testData = [
            'nama_bakul' => 'Test User',
            'alamat' => 'Test Address',
            'berat_ikan' => 100,
            'jumlah_karcis' => 1,
            'jumlah_pembelian' => 1000000,
            'jasa_lelang' => 50000,
            'lain_lain' => 0,
            'total' => 1050000,
            'jumlah_bayar' => 1050000,
            'created_by' => session()->get('user_id') ?? 0,
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->writeLog("TEST Data: " . print_r($testData, true));

        try {
            $this->karcisBakulModel->skipValidation(true);
            if ($this->karcisBakulModel->save($testData)) {
                $insertedID = $this->karcisBakulModel->getInsertID();
                $this->writeLog("✅ TEST SUCCESS: Data saved! Insert ID: " . $insertedID);
                $this->karcisBakulModel->skipValidation(false);
                return "TEST SUCCESS: Data saved! ID: " . $insertedID;
            } else {
                $errors = $this->karcisBakulModel->errors();
                $this->writeLog("❌ TEST FAILED: " . print_r($errors, true));
                $this->karcisBakulModel->skipValidation(false);
                return "TEST FAILED: " . print_r($errors, true);
            }
        } catch (\Exception $e) {
            $this->writeLog("❌ TEST EXCEPTION: " . $e->getMessage());
            $this->karcisBakulModel->skipValidation(false);
            return "TEST EXCEPTION: " . $e->getMessage();
        }
    }

    public function testManualInsert()
    {
        $db = db_connect();

        $testData = [
            'nama_bakul' => 'Test Manual Insert',
            'alamat' => 'Test Alamat Manual',
            'berat_ikan' => 50.5,
            'jumlah_karcis' => 1,
            'jumlah_pembelian' => 1000000,
            'jasa_lelang' => 50000,
            'lain_lain' => 0,
            'total' => 1050000,
            'jumlah_bayar' => 1050000
        ];

        $this->writeLog("MANUAL INSERT TEST: " . print_r($testData, true));

        try {
            $result = $db->table('karcis_bakul')->insert($testData);

            if ($result) {
                $id = $db->insertID();
                $this->writeLog("✅ MANUAL INSERT SUCCESS! ID: " . $id);
                return "MANUAL INSERT SUCCESS! ID: " . $id;
            } else {
                $error = $db->error();
                $this->writeLog("❌ MANUAL INSERT FAILED: " . print_r($error, true));
                return "MANUAL INSERT FAILED: " . print_r($error, true);
            }
        } catch (\Exception $e) {
            $this->writeLog("❌ MANUAL INSERT EXCEPTION: " . $e->getMessage());
            return "EXCEPTION: " . $e->getMessage();
        }
    }

    // Helper function untuk clean number (menghapus titik/kom separator ribuan)
    private function cleanNumber($number)
    {
        if ($number === null || $number === '') return 0;
        if (is_numeric($number)) return $number;
        $n = str_replace('.', '', $number);
        $n = str_replace(',', '.', $n);
        if (strpos($n, '.') !== false) {
            return (float) $n;
        }
        return (int) $n;
    }

    // Helper function untuk menulis log debug sederhana
    private function writeLog($message)
    {
        $logFile = WRITEPATH . 'logs/petugas_debug.log';
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND | LOCK_EX);
    }
}
