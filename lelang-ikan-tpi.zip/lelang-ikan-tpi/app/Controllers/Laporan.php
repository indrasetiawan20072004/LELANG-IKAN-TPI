<?php
namespace App\Controllers;

use App\Models\LaporanModel;

class Laporan extends BaseController
{
    protected $laporanModel;

    public function __construct()
    {
        helper('number');
        $this->laporanModel = new LaporanModel();
        // Jangan redirect di constructor karena tidak bisa mengembalikan response dari sini.
        // Gunakan method checkAuth() di tiap method yang butuh proteksi.
    }

    /**
     * Cek otentikasi terpusat.
     * Jika tidak login -> kembalikan RedirectResponse, jika ok -> kembalikan null.
     */
    private function checkAuth()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login');
        }
        return null;
    }

    public function index()
    {
        if ($resp = $this->checkAuth()) return $resp;

        try {
            $startDate = $this->request->getGet('start_date');
            $endDate = $this->request->getGet('end_date');
            $jenisIkan = $this->request->getGet('jenis_ikan');

            // Ambil data mentah dari model
            $rawData = $this->laporanModel->getLaporanIkan($startDate, $endDate, $jenisIkan);

            // Normalisasi / mapping sehingga view dan export menggunakan key yang konsisten
            $lelangData = $this->normalizeLelangArray($rawData);

            // Hitung statistik umum (menggunakan data yang sudah dinormalisasi)
            $statistik = $this->hitungStatistikUmum($lelangData);

            $data = [
                'title' => 'Laporan Hasil Lelang Ikan',
                'lelang' => $lelangData,
                'startDate' => $startDate,
                'endDate' => $endDate,
                'jenisIkan' => $jenisIkan,
                'total_lelang' => $statistik['total_lelang'],
                'total_berat' => $statistik['total_berat'],
                'total_nilai' => $statistik['total_nilai'],
                'avg_harga' => $statistik['avg_harga'],
                'user' => [
                    'nama' => session()->get('nama_lengkap'),
                    'role' => session()->get('role')
                ]
            ];

            return view('laporan/index', $data);

        } catch (\Exception $e) {
            // Fallback view jika ada error
            return view('laporan/error', ['message' => $e->getMessage()]);
        }
    }

    public function detail($id = null)
    {
        if ($resp = $this->checkAuth()) return $resp;

        if (!$id) {
            return redirect()->to('/laporan')->with('error', 'ID lelang tidak valid.');
        }

        $raw = $this->laporanModel->find($id);
        if (!$raw) {
            return redirect()->to('/laporan')->with('error', 'Data lelang tidak ditemukan.');
        }

        // Normalisasi record tunggal
        $lelang = $this->normalizeLelangItem($raw);

        $data = [
            'title' => 'Detail Lelang: ' . ($lelang['jenis_ikan'] ?? '—'),
            'lelang' => $lelang,
            'peserta' => $this->laporanModel->getDetailLaporanIkan($id),
            'user' => [
                'nama' => session()->get('nama_lengkap'),
                'role' => session()->get('role')
            ]
        ];

        return view('laporan/detail', $data);
    }

    public function statistik()
    {
        if ($resp = $this->checkAuth()) return $resp;

        try {
            $statistikIkan = $this->laporanModel->getStatistikPerJenis();
            $rekapBulanan = $this->laporanModel->getRekapBulanan();

            $data = [
                'title' => 'Statistik Lelang Ikan',
                'statistik_ikan' => $statistikIkan,
                'rekap_bulanan' => $rekapBulanan,
                'user' => [
                    'nama' => session()->get('nama_lengkap'),
                    'role' => session()->get('role')
                ]
            ];

            return view('laporan/statistik', $data);
        } catch (\Exception $e) {
            return redirect()->to('/laporan')->with('error', 'Error loading statistik: ' . $e->getMessage());
        }
    }

    public function exportPDF($id = null)
    {
        if ($resp = $this->checkAuth()) return $resp;

        if (!$id) {
            return redirect()->to('/laporan')->with('error', 'ID lelang tidak valid.');
        }

        $raw = $this->laporanModel->find($id);
        if (!$raw) {
            return redirect()->to('/laporan')->with('error', 'Data lelang tidak ditemukan.');
        }

        try {
            $dompdf = new \Dompdf\Dompdf();

            $lelang = $this->normalizeLelangItem($raw);

            $data = [
                'lelang' => $lelang,
                'peserta' => $this->laporanModel->getDetailLaporanIkan($id)
            ];

            $html = view('laporan/export_pdf', $data);
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->render();

            $filename = "lelang-ikan-" . ($lelang['jenis_ikan'] ?? 'unknown') . "-{$id}.pdf";
            $dompdf->stream($filename, ["Attachment" => true]);

        } catch (\Exception $e) {
            return redirect()->to('/laporan')->with('error', 'Error generating PDF: ' . $e->getMessage());
        }
    }

    public function exportExcel()
    {
        if ($resp = $this->checkAuth()) return $resp;

        try {
            $startDate = $this->request->getGet('start_date');
            $endDate = $this->request->getGet('end_date');
            $jenisIkan = $this->request->getGet('jenis_ikan');

            $raw = $this->laporanModel->getLaporanIkan($startDate, $endDate, $jenisIkan);
            $data = $this->normalizeLelangArray($raw);

            $filename = "laporan-lelang-ikan-" . date('Y-m-d') . ".xlsx";

            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="' . $filename . '"');
            header('Cache-Control: max-age=0');

            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();

            // Judul Laporan
            $sheet->setCellValue('A1', 'LAPORAN HASIL LELANG IKAN');
            $sheet->mergeCells('A1:K1');
            $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);
            $sheet->getStyle('A1')->getAlignment()->setHorizontal('center');

            // Periode Laporan
            $periode = "Periode: " . ($startDate ?: 'Semua Data');
            if ($startDate && $endDate) {
                $periode = "Periode: " . $startDate . " s/d " . $endDate;
            }
            $sheet->setCellValue('A2', $periode);
            $sheet->mergeCells('A2:K2');
            $sheet->getStyle('A2')->getAlignment()->setHorizontal('center');

            // Header Tabel
            $headers = ['No', 'Jenis Ikan', 'Tanggal Lelang', 'Lokasi', 'Berat (kg)', 'Harga Awal/kg', 'Harga Akhir/kg', 'Total Nilai', 'Pemenang', 'Jumlah Peserta', 'Status'];

            $column = 'A';
            foreach ($headers as $header) {
                $sheet->setCellValue($column . '4', $header);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                $column++;
            }

            // Style Header
            $headerStyle = [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['rgb' => '2E75B6']]
            ];
            $sheet->getStyle('A4:K4')->applyFromArray($headerStyle);

            // Data
            $row = 5;
            $no = 1;
            foreach ($data as $item) {
                $sheet->setCellValue('A' . $row, $no++);
                $sheet->setCellValue('B' . $row, $item['jenis_ikan']);
                $sheet->setCellValue('C' . $row, $item['tanggal_lelang']);
                $sheet->setCellValue('D' . $row, $item['lokasi_pelelangan']);
                $sheet->setCellValue('E' . $row, $item['berat_total']);
                $sheet->setCellValue('F' . $row, $item['harga_awal_per_kg']);
                $sheet->setCellValue('G' . $row, $item['harga_akhir_per_kg']);
                $sheet->setCellValue('H' . $row, $item['total_nilai_lelang']);
                $sheet->setCellValue('I' . $row, $item['pemenang_lelang'] ?: '-');
                $sheet->setCellValue('J' . $row, $item['jumlah_peserta']);
                $sheet->setCellValue('K' . $row, $item['status_lelang']);
                $row++;
            }

            // Format angka
            if ($row > 5) {
                $sheet->getStyle('E5:E' . ($row-1))->getNumberFormat()->setFormatCode('#,##0.00');
                $sheet->getStyle('F5:H' . ($row-1))->getNumberFormat()->setFormatCode('#,##0');
            }

            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;

        } catch (\Exception $e) {
            return redirect()->to('/laporan')->with('error', 'Error generating Excel: ' . $e->getMessage());
        }
    }

    public function cetak($id = null)
    {
        if ($resp = $this->checkAuth()) return $resp;

        if (!$id) {
            return redirect()->to('/laporan')->with('error', 'ID lelang tidak valid.');
        }

        $raw = $this->laporanModel->find($id);
        if (!$raw) {
            return redirect()->to('/laporan')->with('error', 'Data lelang tidak ditemukan.');
        }

        $lelang = $this->normalizeLelangItem($raw);

        $data = [
            'lelang' => $lelang,
            'peserta' => $this->laporanModel->getDetailLaporanIkan($id),
            'user' => [
                'nama' => session()->get('nama_lengkap'),
                'role' => session()->get('role')
            ]
        ];

        return view('laporan/cetak', $data);
    }

    // ==================== FITUR KHUSUS LELANG IKAN ====================

    public function getStatistikIkan()
    {
        if ($resp = $this->checkAuth()) return $resp;

        try {
            $statistik = $this->laporanModel->getStatistikPerJenis();

            $labels = []; $dataTotal = []; $dataBerat = [];
            foreach ($statistik as $item) {
                $labels[] = $item['jenis_ikan'];
                $dataTotal[] = (float) $item['total_nilai'];
                $dataBerat[] = (float) $item['total_berat'];
            }

            return $this->response->setJSON([
                'labels' => $labels,
                'dataTotal' => $dataTotal,
                'dataBerat' => $dataBerat
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON(['error' => $e->getMessage()]);
        }
    }

    public function getRekapBulanan()
    {
        if ($resp = $this->checkAuth()) return $resp;

        try {
            $rekap = $this->laporanModel->getRekapBulanan();

            $labels = []; $dataLelang = []; $dataNilai = [];
            foreach ($rekap as $item) {
                $labels[] = $item['bulan'];
                $dataLelang[] = (int) $item['total_lelang'];
                $dataNilai[] = (float) $item['total_nilai'];
            }

            return $this->response->setJSON([
                'labels' => $labels,
                'dataLelang' => $dataLelang,
                'dataNilai' => $dataNilai
            ]);
        } catch (\Exception $e) {
            return $this->response->setJSON(['error' => $e->getMessage()]);
        }
    }

    public function apiChartData()
    {
        if ($resp = $this->checkAuth()) return $resp;

        $chartType = $this->request->getGet('type');

        switch ($chartType) {
            case 'jenis_ikan': return $this->getStatistikIkan();
            case 'bulanan': return $this->getRekapBulanan();
            default: return $this->response->setJSON(['error' => 'Invalid chart type']);
        }
    }

    private function hitungStatistikUmum($data)
    {
        $total_lelang = count($data);
        $total_berat = 0; $total_nilai = 0; $total_harga = 0;

        foreach ($data as $item) {
            $total_berat += (float) ($item['berat_total'] ?? 0);
            $total_nilai += (float) ($item['total_nilai_lelang'] ?? 0);
            if (!empty($item['harga_akhir_per_kg'])) {
                $total_harga += (float) $item['harga_akhir_per_kg'];
            }
        }

        $avg_harga = $total_lelang > 0 ? $total_harga / $total_lelang : 0;

        return [
            'total_lelang' => $total_lelang,
            'total_berat' => $total_berat,
            'total_nilai' => $total_nilai,
            'avg_harga' => $avg_harga
        ];
    }

    /**
     * Normalisasi array hasil query model menjadi format yang konsisten untuk view/export/statistik
     * Meng-handle kemungkinan nama kolom berbeda dari model.
     */
    private function normalizeLelangArray($raw)
    {
        $mapped = [];
        foreach ($raw as $item) {
            $mapped[] = $this->normalizeLelangItem($item);
        }
        return $mapped;
    }

    private function normalizeLelangItem($item)
    {
        // Contoh peng-mapping-an kolom yang mungkin beda nama di model
        return [
            'id_lelang' => $item['id_lelang'] ?? ($item['id'] ?? null),
            // beberapa model menggunakan nama_lelang untuk menyimpan jenis ikan
            'jenis_ikan' => $item['jenis_ikan'] ?? $item['nama_lelang'] ?? $item['jenis'] ?? '-',
            'tanggal_lelang' => $item['tanggal_lelang'] ?? $item['tanggal'] ?? ($item['created_at'] ?? '-'),
            'lokasi_pelelangan' => $item['lokasi_pelelangan'] ?? $item['lokasi'] ?? ($item['tempat'] ?? '-'),
            'berat_total' => isset($item['berat_total']) ? (float) $item['berat_total'] : (isset($item['berat_ikan']) ? (float) $item['berat_ikan'] : 0),
            'harga_awal_per_kg' => $item['harga_awal_per_kg'] ?? $item['harga_awal'] ?? 0,
            'harga_akhir_per_kg' => $item['harga_akhir_per_kg'] ?? $item['harga_akhir'] ?? 0,
            'total_nilai_lelang' => $item['total_nilai_lelang'] ?? $item['total_nilai'] ?? 0,
            'pemenang_lelang' => $item['pemenang_lelang'] ?? $item['pemenang'] ?? ($item['winner'] ?? null),
            'status_lelang' => $item['status_lelang'] ?? $item['status'] ?? '-',
            'jumlah_peserta' => $item['jumlah_peserta'] ?? $item['jumlah'] ?? ($item['total_peserta'] ?? 0)
        ];
    }
}
