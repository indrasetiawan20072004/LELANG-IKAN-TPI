<?php 
namespace Config;

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

// Basic Configuration
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Auth');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false); // UBAH KE false

// ===== ROUTES UTAMA =====
$routes->get('/', 'Auth::index');
$routes->get('/auth/login', 'Auth::login');
$routes->post('/auth/login', 'Auth::login');
$routes->get('/auth/logout', 'Auth::logout');

// ===== DASHBOARD ROUTES =====
$routes->get('/admin', 'Admin::index');
$routes->get('/petugas', 'Petugas::index');

// ===== ROUTES LAPORAN =====
$routes->get('/laporan', 'Laporan::index');
$routes->get('/laporan/detail/(:num)', 'Laporan::detail/$1');
$routes->get('/laporan/statistik', 'Laporan::statistik');
$routes->get('/laporan/exportPDF/(:num)', 'Laporan::exportPDF/$1');
$routes->get('/laporan/exportExcel', 'Laporan::exportExcel');

// ===== ADMIN LAPORAN ROUTES =====
$routes->get('/admin/laporan', 'Laporan::index');  
$routes->get('/admin/laporan/export', 'Laporan::exportExcel');

// ===== TEST ROUTES =====
$routes->get('/test-admin', function() {
    return "TEST: Admin page accessible!";
});

$routes->get('/test-dashboard', function() {
    if (!session()->get('logged_in')) {
        return "NOT LOGGED IN";
    }
    return "TEST: Dashboard accessible! User: " . session()->get('nama_lengkap');
});

$routes->get('/test-session', function() {
    return "Session: " . print_r(session()->get(), true);
});

// ===== ROUTES EXISTING LAINNYA =====
$routes->get('/debug', 'Debug::index');
$routes->get('/simple-test', 'SimpleTest::index');
$routes->match(['get', 'post'], '/simple-test/login', 'SimpleTest::login');

// Petugas Routes
$routes->get('/petugas/input-karcis-bakul', 'Petugas::inputKarcisBakul');
$routes->post('/petugas/input-karcis-bakul', 'Petugas::inputKarcisBakul');
$routes->get('/petugas/input-karcis-pemilik-kapal', 'Petugas::inputKarcisPemilikKapal');
$routes->post('/petugas/input-karcis-pemilik-kapal', 'Petugas::inputKarcisPemilikKapal');
$routes->get('/petugas/daftar-karcis-bakul', 'Petugas::daftarKarcisBakul');
$routes->get('/petugas/daftar-karcis-pemilik-kapal', 'Petugas::daftarKarcisPemilikKapal');
$routes->get('/debug-session', 'SessionDebug::index');

// Karcis Routes
$routes->get('/karcis-bakul', 'KarcisBakul::index');
$routes->post('/karcis-bakul/simpan', 'KarcisBakul::simpan');
$routes->get('/karcis-bakul/sukses', 'KarcisBakul::sukses');

$routes->get('/input-karcis/pemilik-kapal', 'InputKarcis::pemilikKapal');
$routes->post('/input-karcis/pemilik-kapal', 'InputKarcis::pemilikKapal');


$routes->get('/test-input-bakul', 'Petugas::testInputBakul');




$routes->get('/test-manual-insert', 'Petugas::testManualInsert');

$routes->post('/input-karcis/bakul', 'InputKarcis::bakul');

$routes->post('/working-input/bakul', 'WorkingInput::bakul');
$routes->get('/petugas/input-sukses', 'Petugas::inputSukses');
$routes->post('/working-input/pemilik-kapal', 'WorkingInput::pemilikKapal');
$routes->get('/petugas/input-sukses-kapal', 'Petugas::inputSuksesKapal');