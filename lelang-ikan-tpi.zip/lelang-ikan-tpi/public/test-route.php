<?php
echo "<h1>Route Test</h1>";
echo "<p>Jika halaman ini muncul, PHP bekerja.</p>";
echo "<p><a href='/auth/login'>Test: /auth/login</a></p>";
echo "<p><a href='/debug'>Test: /debug</a></p>";
echo "<p><a href='/'>Test: / (root)</a></p>";
?>