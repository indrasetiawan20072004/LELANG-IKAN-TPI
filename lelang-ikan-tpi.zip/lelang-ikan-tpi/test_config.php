<?php
require_once 'config.php';
echo "✅ Koneksi database berhasil!";
echo "<br>Database: " . $database;
echo "<br>Host: " . $host;
?>